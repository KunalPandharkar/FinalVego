@extends('layouts.mainlayout')
@section('title', 'VeGO-Aapka Apna Garage!')
@section('searchbar')
@endsection
@section('userlocation')
@endsection

@section('content')
     <!-- price card -->
     <section>
        <div class="defaultcard pricetable-c">
            <div class="heading">
                <h5>Our Prices</h5>
                <hr class="headingunderline">
            </div>

            <div class="price-table">

                <div class="price-item">
                    <div class="price-cat">
                        <p>Washing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 100</p>
                    </div>
                </div>

                <div class="price-item1">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item">
                    <div class="price-cat">
                        <p>AC Repair</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 500</p>
                    </div>
                </div>

                <div class="price-item1">
                    <div class="price-cat">
                        <p>Oil Services</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 200</p>
                    </div>
                </div>

                <div class="price-item">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item1">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item1">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item1">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                <div class="price-item">
                    <div class="price-cat">
                        <p>Servicing</p>
                    </div>
                    <div class="price-rs">
                        <p>₹ 300</p>
                    </div>
                </div>

                

                

            </div>
        </div>
    </section>
    <!-- price card ends -->
   
@endsection
   