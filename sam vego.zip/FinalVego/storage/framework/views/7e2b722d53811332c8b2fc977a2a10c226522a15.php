<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- login form -->
<section class="defaultcard">
    <div class="heading">
        <h5>Sign In</h5>
        <hr class="headingunderline">
    </div>

    <?php if($message=session()->get('faillogin')): ?>
    <div class="alert alert-danger alert-dismissible fade show alert-msg" role="alert">
        <p><?php echo e($message); ?></p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>

    <form action="logincustomer" method="post">
        <?php echo csrf_field(); ?>
        <div class="loginform">
            <div class="form-group fg-log">
                <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Mobile Number" name="phone">
            </div>
            <div class="form-group fg-log">
                <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Password" name="password">
            </div>
            <div class="form-group fg-log1">
                <button type="submit" class="btn">Login</button>
            </div>
            <a href="register.html" class="reg-link">Don't Have an Account ? Click to Register</a>
            <div class="form-group fg-log fg-log2">
                <img src="assets/images/google-symbol.svg" alt="">
                <a href="" class="btn">Sign Up With Google</a>
            </div>
            <div class="form-group fg-log fg-log3">
                <img src="assets/images/facebook-symbol.svg" alt="">
                <a href="" class="btn">Sign Up with Facebook</a>
            </div>
        </div>
    </form>

</section>
<!-- loginform ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/login.blade.php ENDPATH**/ ?>