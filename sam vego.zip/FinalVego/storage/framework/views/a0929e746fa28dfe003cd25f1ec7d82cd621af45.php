<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="price-table">

    <div class="price-item">
        <div class="price-cat">
            <input type="text" class="form-control" value="Washing">
        </div>
        <div class="price-rs">
            <input type="text" class="form-control" value="₹ 100">
        </div>
    </div>

    <div class="price-item1">
        <div class="price-cat">
            <input type="text" class="form-control" value="Servicing">
        </div>
        <div class="price-rs">
            <input type="text" class="form-control" value="₹ 200">
        </div>
    </div>

    <div class="price-item">
        <div class="price-cat">
            <input type="text" class="form-control" value="Washing">
        </div>
        <div class="price-rs">
            <input type="text" class="form-control" value="₹ 100">
        </div>
    </div>

    <div class="price-item1">
        <div class="price-cat">
            <input type="text" class="form-control" value="Servicing">
        </div>
        <div class="price-rs">
            <input type="text" class="form-control" value="₹ 200">
        </div>
    </div>

    <div class="price-item">
        <div class="price-cat">
            <input type="text" class="form-control" value="Washing">
        </div>
        <div class="price-rs">
            <input type="text" class="form-control" value="₹ 100">
        </div>
    </div>


    </div>

    <div class="form-group fg1 addser">
        <label for="exampleFormControlInput1">Add More Services :</label>
        <select class="custom-select fg2" id="inlineFormCustomSelect" name="grgtype">
            <option value="">Service 1</option>
            <option value="">Service 2</option>
        </select>
    </div>

    <div class="addservicebtn1">
        <a href="servicesadd"><button type="button" class="btn">Submit</button></a>
    </div>

    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/servicesadd.blade.php ENDPATH**/ ?>