<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section>


        <?php
        $img = DB::table('garagephotos')->where('garage_id', $garageinfo->id)->get('garage_photo');
        ?>


        <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
            <div class="carousel-inner">
                <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($img) != $key + 1): ?>
                        <div class="carousel-item">
                            <img src="<?php echo e(asset('/storage/img/garages/' . $i->garage_photo)); ?>" class="d-block w-100">
                        </div>
                    <?php else: ?>
                        <div class="carousel-item active">
                            <img src="<?php echo e(asset('/storage/img/garages/' . $i->garage_photo)); ?>" class="d-block w-100">
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <div class="scroll">
            <div class="horizontal-scroll">
                <div class="scroll-container infopageimgs">
                    <?php $__currentLoopData = $img; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <img src="<?php echo e(asset('/storage/img/garages/' . $i->garage_photo)); ?>"
                            data-target="#carouselExampleFade" data-slide-to="<?php echo e($key); ?>">
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

    </section>

    <!-- garagehead card -->
    <section class="stick-t">
        <div class="defaultcard">
            <div class="headtext">
                <h5><?php echo e($garageinfo->garage_name); ?></h5>
            </div>
            <div class="headratings">
                <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
            </div>
            <div class="headstatus">
                <p>Open Now <span> -
                        <?php echo e($regdate = \Carbon\Carbon::createFromFormat('H:i', $garageinfo->opening_time)->format('h:i A')); ?>-
                        <?php echo e($regdate = \Carbon\Carbon::createFromFormat('H:i', $garageinfo->closing_time)->format('h:i A')); ?>

                    </span>
                    <span id="hstype">


                        ( <?php
                        $type = DB::table('garagetypes')->where('garage_id', $garageinfo->id)->get('garage_type');

                        $s = array();

                        foreach ($type as $t){
                        $s[]=$t->garage_type;
                        }
                        ?>

                        <?php
                        echo implode(',', $s);
                        ?>

                        Wheeler )
                    </span>
                </p>
            </div>
            <div class="headadress">
                <p><?php echo e($garageinfo->garage_address); ?></p>
            </div>
            <div class="pricebtn">
                <button class="btn" onclick="location.href='/pricecard.html/<?php echo e($garageinfo->id); ?>'">Price Card</button>
                <a href="" class="btn">
                    <img src=<?php echo e(asset('assets/images/call.svg')); ?> alt="">
                </a>
                <a href="" class="btn wha">
                    <img src=<?php echo e(asset('assets/images/whatsapp.svg')); ?> alt="">
                </a>
            </div>
        </div>
    </section>
    <!-- garagehead card end -->

    <!-- garage services -->

    <section>
        <div class="defaultcard">
            <div class="heading">
                <h5>Our Services</h5>
                <hr class="headingunderline">
            </div>
            <div class="grgservices">
                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice1.svg')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>AC Repair</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice2.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Avg. Check</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice3.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Break Suspension</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice4.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Diagnosis</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice5.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Engine Repair</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice6.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Full Servicing</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice7.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Vehicle Wash</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice8.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Tyre Replacement</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>

                <div class="grgservice">
                    <div class="grgserviceimg">
                        <img src=<?php echo e(asset('assets/images/grgservice9.png')); ?> alt="">
                    </div>
                    <div class="grgservicetxt">
                        <div class="grgsername">
                            <p>Oil services</p>
                        </div>
                        <div class="grgserprice">
                            <p>₹ 500-700</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- garage services end -->

    <!-- about garage -->
    <section>
        <div class="defaultcard">

            <div class="heading">
                <h5>About Garage</h5>
                <hr class="headingunderline">
            </div>


            <div class="garageabt">
                <div class="cellabt clr">
                    <div class="cell1">
                        <p>Owner</p>
                    </div>
                    <div class="cell2">
                        <p><?php echo e($owner->first_name); ?> <?php echo e($owner->last_name); ?></p>
                    </div>
                </div>
                <div class="cellabt ">
                    <div class="cell1">
                        <p>Garage Name</p>
                    </div>
                    <div class="cell2">
                        <?php echo e($garageinfo->garage_name); ?>

                    </div>
                </div>


                <div class="cellabt clr">
                    <div class="cell1">
                        <p>Contact 1</p>
                    </div>
                    <div class="cell2 scmd scmd2">
                        <p><?php echo e($owner->contact1); ?></p>
                        <img src=<?php echo e(asset('assets/images/edit2.svg')); ?> alt="">
                    </div>
                </div>
                <div class="cellabt ">
                    <div class="cell1">
                        <p>Contact 2</p>
                    </div>
                    <div class="cell2 scmd scmd2">
                        <p><?php echo e($owner->contact2); ?></p>
                        <img src=<?php echo e(asset('assets/images/edit2.svg')); ?> alt="">
                    </div>
                </div>
                <div class="cellabt clr">
                    <div class="cell1 scmd">
                        <p>Whatsapp</p>
                        <img src=<?php echo e(asset('assets/images/whatsapp.svg')); ?> alt="">
                    </div>
                    <div class="cell2 scmd scmd2">
                        <p><?php echo e($owner->cust_whatsapp); ?></p>
                        <img src=<?php echo e(asset('assets/images/edit2.svg')); ?> alt="">
                    </div>
                </div>

            </div>

    </section>
    <!-- about garage end -->

    <!-- customer reviews -->
    <?php
    $cmnts=DB::table('customerreviews')->where('garage_id',$garageinfo->id)->get();
    ?>
  <?php if(!$cmnts ->isempty()): ?>

    <section class="defaultcard revcont">

        <div class="heading">
            <h5>From Our Customers</h5>
            <hr class="headingunderline">
        </div>

        <div id="carouselExampleFade2" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner reviewcard-c1">



                <?php $__currentLoopData = $cmnts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($cmnts) != $key + 1): ?>
                        <div class="carousel-item reviewcard-c">
                            <div class="reviewcard">
                                <div class="reviewname">
                                    <p><?php echo e(session()->get('firstname')); ?></p>
                                </div>
                                <div class="ratings1">
                                    <?php for($i = 1; $i <= $c->ratings; $i++): ?>
                                        <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                                    <?php endfor; ?>
                                </div>
                                <div class="reviewdate">

                                    <p><?php echo e($c->created_at); ?>

                                    </p>
                                </div>

                                <div class="reviewtxt">
                                    <p>
                                        <?php echo e($c->comment); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="carousel-item reviewcard-c active">
                            <div class="reviewcard">
                                <div class="reviewname">
                                    <p><?php echo e(session()->get('firstname')); ?></p>
                                </div>
                                <div class="ratings1">
                                    <?php for($i = 1; $i <= $c->ratings; $i++): ?>
                                        <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                                    <?php endfor; ?>
                                </div>
                                <div class="reviewdate">
                                    <p><?php echo e($c->created_at); ?>

                                    </p>
                                </div>

                                <div class="reviewtxt">
                                    <p>
                                        <?php echo e($c->comment); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <a class="carousel-control-prev nav-review1" href="#carouselExampleFade2" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next nav-review2" href="#carouselExampleFade2" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>


    </section>
    <?php endif; ?>
    <!-- customer reviews ends -->

    <!-- garage ratings -->
    <section>
        <div class="defaultcard">

            <div class="heading">
                <h5>Customer Ratings</h5>
                <hr class="headingunderline">
            </div>


            <form action="/storecustomerreviews" method="post">
                <?php echo csrf_field(); ?>
                <div class="rate-cust">
                    <div class="tap-rate">
                        <p>Tap to Rate Our Garage</p>
                    </div>

                    <div class="rating-grg">
                        <label class="container ratinglabel">
                            <input type="radio" name="radio" id="radiobox" value="1">
                            <span class="" onclick="starchecked(this.id)" id="1">☆</span>

                        </label>
                        <label class="container ratinglabel">
                            <input type="radio" name="radio" id="radiobox" value="2" onclick="starchecked(2)">
                            <span class="" onclick="starchecked(this.id)" id="2">☆</span>

                        </label> <label class="container ratinglabel">
                            <input type="radio" name="radio" id="radiobox" value="3" onclick="starchecked(3)">
                            <span class="" onclick="starchecked(this.id)" id="3">☆</span>

                        </label> <label class="container ratinglabel">
                            <input type="radio" name="radio" id="radiobox" value="4" onclick="starchecked(4)">
                            <span class="" onclick="starchecked(this.id)" id="4">☆</span>

                        </label> <label class="container ratinglabel">
                            <input type="radio" name="radio" id="radiobox" value="5" onclick="starchecked(5)">
                            <span class="" onclick="starchecked(this.id)" id="5">☆</span>

                        </label>


                        <p class="clear-r">
                            Clear
                        </p>
                    </div>

                    <input type="hidden" name="grgid" value="<?php echo e($garageinfo->id); ?>">
                    <div class="form-group fg1 my-3 commentsbox">
                        <textarea name="customercomment" class="form-control" cols="10" rows="3"
                            placeholder="Write Us Something..."></textarea>
                        <button type="submit" class="btn subcomments mt-4">Submit</button>
                    </div>
                </div>
            </form>




            <div class="grgrating-cont">
                <div class="grgratings-c">
                    <div class="grgr">
                        <div class="grg1">
                            <h3>5.0</h3>
                        </div>
                        <div class="grg2">
                            <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                            <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                            <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                            <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                            <img src=<?php echo e(asset('assets/images/star.svg')); ?> alt="">
                        </div>
                        <div class="grg3">
                            <p>Good</p>
                        </div>
                    </div>
                </div>
                <div class="grgratings">
                    <div class="grgrating-bars">
                        <div class="row-c">
                            <div class="rowc">
                                <div class="col-r">
                                    <span>5</span>
                                    <img src="assets/images/star-black.svg" alt="">
                                </div>
                                <div class="middle">
                                    <div class="bar-container">
                                        <div class="bar-5"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="rowc">
                                <div class="col-r">
                                    <span>4</span>
                                    <img src="assets/images/star-black.svg" alt="">
                                </div>
                                <div class="middle">
                                    <div class="bar-container">
                                        <div class="bar-4"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="rowc">
                                <div class="col-r">
                                    <span>3</span>
                                    <img src="assets/images/star-black.svg" alt="">
                                </div>
                                <div class="middle">
                                    <div class="bar-container">
                                        <div class="bar-3"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="rowc">
                                <div class="col-r">
                                    <span>2</span>
                                    <img src="assets/images/star-black.svg" alt="">
                                </div>
                                <div class="middle">
                                    <div class="bar-container">
                                        <div class="bar-2"></div>
                                    </div>
                                </div>
                            </div>

                            <div class="rowc">
                                <div class="col-r">
                                    <span>1</span>
                                    <img src="assets/images/star-black.svg" alt="">
                                </div>
                                <div class="middle">
                                    <div class="bar-container">
                                        <div class="bar-1"></div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>



        </div>
    </section>
    <!-- garage ratings end -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/garageinfo.blade.php ENDPATH**/ ?>