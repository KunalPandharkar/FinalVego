
<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<section>
    <div class="loader-cont">
        <div class="loaderimg1">
            <img src="assets/images/preloader1.png" alt="">
        </div>

        <div id="loader1">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            <span></span>
        </div>

        <div class="loaderimg2">
            <img src="assets/images/preloader.png" alt="">
        </div>
    </div>
    <div class="msg-load">
        <p>Wait ! We are connecting with Garage ...</p>
    </div>
</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/preloader.blade.php ENDPATH**/ ?>