<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- register form -->
<section class="defaultcard">
    <div class="heading">
        <h5>Sign Up</h5>
        <hr class="headingunderline">
    </div>

    <?php if($message=session()->get('message')): ?>
    <div class="alert alert-danger alert-dismissible fade show alert-msg" role="alert">
        <p><?php echo e($message); ?></p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <?php endif; ?>


<form action="registercustomer" method="post">
    <?php echo csrf_field(); ?>
    <div class="loginform">
        <div class="form-group fg-log">
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Mobile Number" name="phone" required>
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger">
                <?php echo e($message); ?>

            </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group fg-log">
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Your City" name="city" required>
            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger">
                <?php echo e($message); ?>

            </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group fg-log">
            <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Password" name="password" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class="text-danger">
                <?php echo e($message); ?>

            </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group fg-log">
            <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Confirm Password" name="password_confirmation" required>
        </div>
        <div class="form-group fg-log1">
            <button type="submit" class="btn">Register</button>
        </div>
        <a href="login.html" class="reg-link">Already Have an Account ? Click to Login</a>
        <div class="form-group fg-log fg-log2">
            <img src="assets/images/google-symbol.svg" alt="">
            <a href="" class="btn">Sign Up With Google</a>
        </div>
        <div class="form-group fg-log fg-log3">
            <img src="assets/images/facebook-symbol.svg" alt="">
            <a href="" class="btn">Sign Up with Facebook</a>
        </div>
    </div>
</form>


</section>
<!-- registerform ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/register.blade.php ENDPATH**/ ?>