@extends('layouts.mainlayout')
@section('title', 'VeGO-Aapka Apna Garage!')
@section('searchbar')
@endsection
@section('userlocation')
@endsection

@section('content')
    <!-- register form -->
<section class="defaultcard">
    <div class="heading">
        <h5>Sign Up</h5>
        <hr class="headingunderline">
    </div>

    @if ($message=session()->get('message'))
    <div class="alert alert-danger alert-dismissible fade show alert-msg" role="alert">
        <p>{{$message}}</p>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
    </div>
    @endif


<form action="registercustomer" method="post">
    @csrf
    <div class="loginform">
        <div class="form-group fg-log">
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Mobile Number" name="phone" required>
            @error('phone')
            <small class="text-danger">
                {{$message}}
            </small>
            @enderror
        </div>

        <div class="form-group fg-log">
            <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Your City" name="city" required>
            @error('city')
            <small class="text-danger">
                {{$message}}
            </small>
            @enderror
        </div>
        <div class="form-group fg-log">
            <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Password" name="password" required>
            @error('password')
            <small class="text-danger">
                {{$message}}
            </small>
            @enderror
        </div>
        <div class="form-group fg-log">
            <input type="password" class="form-control" id="exampleFormControlInput1" placeholder="Confirm Password" name="password_confirmation" required>
        </div>
        <div class="form-group fg-log1">
            <button type="submit" class="btn">Register</button>
        </div>
        <a href="login.html" class="reg-link">Already Have an Account ? Click to Login</a>
        <div class="form-group fg-log fg-log2">
            <img src="assets/images/google-symbol.svg" alt="">
            <a href="" class="btn">Sign Up With Google</a>
        </div>
        <div class="form-group fg-log fg-log3">
            <img src="assets/images/facebook-symbol.svg" alt="">
            <a href="" class="btn">Sign Up with Facebook</a>
        </div>
    </div>
</form>


</section>
<!-- registerform ends -->

@endsection
