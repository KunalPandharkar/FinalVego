@extends('layouts.mainlayout')
@section('title', 'VeGO-Aapka Apna Garage!')
@section('searchbar')
@endsection
@section('userlocation')
@endsection

@section('content')
    <!-- price card -->
    <section>
        <div class="defaultcard pricetable-c">
            <div class="heading">
                <h5>Our Prices</h5>
                <hr class="headingunderline">
            </div>

            <div class="price-table">

                @foreach ($services as $service)

                    @if ($loop->iteration % 2 == 0)
                        <div class="price-item">
                            <div class="price-cat">
                                <p>
                                    @php
                                    $ser=DB::table('services')->where('id',$service->service_id)->first();
                                    @endphp
                                    {{ $ser->service_name }}
                                </p>
                            </div>
                            <div class="price-rs">
                                <p>₹ 100</p>
                            </div>
                        </div>
                    @else
                        <div class="price-item1">
                            <div class="price-cat">
                                <p>
                                    @php
                                    $ser=DB::table('services')->where('id',$service->service_id)->first();
                                    @endphp
                                    {{ $ser->service_name }}
                                </p>
                            </div>
                            <div class="price-rs">
                                <p>₹ 100</p>
                            </div>
                        </div>
                    @endif

                @endforeach



            </div>
        </div>
    </section>
    <!-- price card ends -->

@endsection
