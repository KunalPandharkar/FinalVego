<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <!-- login form -->
     <section class="defaultcard">
        <div class="heading">
            <h5>My Profile</h5>
            <hr class="headingunderline">
        </div>

        <?php if($message=session()->get('msg')): ?>
        <div class="alert alert-success alert-dismissible fade show alert-msg" role="alert">
            <p><?php echo e($message); ?></p>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>

        <div class="userprofile-in">
            <div class="usericon ui1">
                <img src="assets/images/user.svg" alt="">
            </div>
            <div class="username un1">
                <p>Hello <?php echo e($usersdata->first_name); ?> !</p>
                <p><?php echo e($usersdata->contact1); ?></p>
            </div>

        </div>

        <form action="updatecustomer" method="post">
            <?php echo csrf_field(); ?>
            <div class="usereditform">
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">First Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($usersdata->first_name); ?>" name="fname">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Last Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($usersdata->last_name); ?>" name="lname">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Your City</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($usersdata->cust_city); ?>" name="city">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Mobile Number</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" value="<?php echo e($usersdata->contact1); ?>" name="phone">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Password</label>
                    <input type="password" class="form-control" id="exampleFormControlInput1" value="<?php echo e($usersdata->cust_password); ?>" name="password">
                </div>
                <input type="hidden" value="<?php echo e($usersdata->id); ?>" name="userid">


                <div class="form-group fg-log us-gender">
                    <div class="form-check form-check-inline">

                        <input class="form-check-input" type="radio" id="inlineRadio1"
                            value="male" name="gender"
                            <?php if($usersdata->cust_gender === 'male'): ?>
                            checked
                            <?php endif; ?>>

                        <label class="form-check-label" for="inlineRadio1">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" id="inlineRadio2"
                            value="female" name="gender"
                            <?php if($usersdata->cust_gender === 'female'): ?>
                            checked
                            <?php endif; ?>>
                        <label class="form-check-label">Female</label>
                    </div>
                </div>
                <div class="form-group fg-log fg-space">
                    <label for="exampleInputEmail1">Email ID</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1"
                    value="<?php echo e($usersdata->cust_mail); ?>" name="email">
                </div>
            </div>
            <div class="fg-us">
                <button class="btn rst">Reset</button>
                <button type="submit" class="btn">Update</a>
            </div>
        </form>

    </section>
    <!-- loginform ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/userprofile.blade.php ENDPATH**/ ?>