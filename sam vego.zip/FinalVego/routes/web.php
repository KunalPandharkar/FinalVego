<?php

use App\Http\Controllers\CustomerController;
use Illuminate\Support\Facades\Route;


Route::get('/aboutus.html', function () {
    return view('aboutus');
});

Route::get('/contactus.html', function () {
    return view('contactus');
});

Route::get('/editgarage.html', function () {
    return view('editgarage');
});

Route::get('/editservicecenter.html', function () {
    return view('editservicecenter');
});

Route::get('/emergencyinfo.html', function () {
    return view('emergencyinfo');
});

Route::get('/emergencyservice.html', function () {
    return view('emergencyservice');
});


Route::get('/login.html', function () {
    return view('login');
});

Route::get('/offers.html', function () {
    return view('offers');
});

Route::get('/preloader.html', function () {
    return view('preloader');
});

Route::get('/pricecard.html', function () {
    return view('pricecard');
});

Route::get('/register.html', function () {
    return view('register');
});

Route::get('/registergarage.html', function () {
    return view('registergarage');
});

Route::get('/registerservicecenter.html', function () {
    return view('registerservicecenter');
});

Route::get('/registerservicecenterform.html', function () {
    return view('registerservicecenterform');
});

Route::get('/servicecenters.html', function () {
    return view('servicecenters');
});

Route::get('/workwithus.html', function () {
    return view('workwithus');
});


// -------------------

Route::post('/registercustomer','CustomerController@registercustomer');
Route::post('updatecustomer','CustomerController@storeupdatecustomer');
Route::get('/userprofile.html','CustomerController@updatecustomer');
Route::post('/logincustomer','CustomerController@logincustomer');
Route::get('/logoutcustomer','CustomerController@logoutcustomer');
Route::get('/index.html','CustomerController@index');
Route::get('/','CustomerController@index');
Route::get('/registergarageform.html','CustomerController@registergarageshow');
Route::get('/registerservicecenterform.html','CustomerController@registerservicecentershow');
Route::post('storeregistergarage','CustomerController@storeregistergarage');
Route::get('/garages.html','CustomerController@showregisteredgarages');
Route::get('/servicecenters.html','CustomerController@showregisteredservicecenters');
Route::get('/servicesadd', function () {
    return view('servicesadd');
});
Route::get('/garageinfo.html/{id}','CustomerController@getgaragebyid');
Route::get('/pricecard.html/{id}','CustomerController@showservices');
Route::post('/storecustomerreviews','CustomerController@storecustomerreviews');
