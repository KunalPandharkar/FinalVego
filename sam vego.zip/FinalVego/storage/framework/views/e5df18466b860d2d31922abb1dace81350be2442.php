<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- price card -->
    <section>
        <div class="defaultcard pricetable-c">
            <div class="heading">
                <h5>Our Prices</h5>
                <hr class="headingunderline">
            </div>

            <div class="price-table">

                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($loop->iteration % 2 == 0): ?>
                        <div class="price-item">
                            <div class="price-cat">
                                <p>
                                    <?php
                                    $ser=DB::table('services')->where('id',$service->service_id)->first();
                                    ?>
                                    <?php echo e($ser->service_name); ?>

                                </p>
                            </div>
                            <div class="price-rs">
                                <p>₹ 100</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="price-item1">
                            <div class="price-cat">
                                <p>
                                    <?php
                                    $ser=DB::table('services')->where('id',$service->service_id)->first();
                                    ?>
                                    <?php echo e($ser->service_name); ?>

                                </p>
                            </div>
                            <div class="price-rs">
                                <p>₹ 100</p>
                            </div>
                        </div>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </div>
        </div>
    </section>
    <!-- price card ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\FinalVego\resources\views/pricecard.blade.php ENDPATH**/ ?>