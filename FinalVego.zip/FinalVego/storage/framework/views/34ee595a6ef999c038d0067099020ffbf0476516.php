<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- register form -->
    <section class="defaultcard">
        <div class="heading">
            <h5>Sign Up</h5>
            <hr class="headingunderline">
        </div>
        <form action="registercustomer" method="post">
            <?php echo csrf_field(); ?>
            <div class="loginform">
                <div class="form-group fg-log">
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="phone"
                        placeholder="Mobile Number" required>
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <div class="form-group fg-log">
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="city"
                        placeholder="Your City" required>
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <div class="form-group fg-log">
                    <input type="password" class="form-control" id="password" name="password" placeholder="Password"
                        required>
                </div>
                <div class="form-group fg-log">
                    <input type="password" class="form-control" id="confirm_passowrd" placeholder="Confirm Password"
                        name="password_confirmation" required>
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <div class="form-group fg-log1">
                    <button class="btn" type="submit">Register</button>
                    <small class="alreadyregwarning">
                       <?php if($message = Session::get('alreadyregistered')): ?>
                           <?php echo e($message); ?>

                       <?php endif; ?>
                    </small>
                </div>
                <a href="login.html" class="reg-link">Already Have an Account ? Click to Login</a>
                <div class="form-group fg-log fg-log2">
                    <img src="assets/images/google-symbol.svg" alt="">
                    <a href="" class="btn">Sign Up With Google</a>
                </div>
                <div class="form-group fg-log fg-log3">
                    <img src="assets/images/facebook-symbol.svg" alt="">
                    <a href="" class="btn">Sign Up with Facebook</a>
                </div>
            </div>
        </form>
    </section>
    <!-- registerform ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\FinalVego\FinalVego\resources\views/register.blade.php ENDPATH**/ ?>