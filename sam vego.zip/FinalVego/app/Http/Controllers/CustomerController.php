<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function index()
    {

        $fname = DB::table('customers')->where('id', session()->get('user'))->value('first_name');
        $city = DB::table('customers')->where('id', session()->get('user'))->value('cust_city');
        $phoneno = DB::table('customers')->where('id', session()->get('user'))->value('contact1');

        if (session()->has('user')) {
            session([
                'phoneno' => $phoneno,
                'firstname' => $fname,
                'cityname' => $city
            ]);
        } else {
            session(
                [
                    'cityname' => 'Parbhani'
                ]
            );
        }


        return view('index');
    }
    public function registercustomer(Request $request)
    {
        $validatedData = $request->validate([
            'phone' => 'digits:10|required',
            'city' => 'alpha|max:20|required',
            'password' => 'alpha_num|min:8|max:15|required|confirmed'
        ]);

        try {
            $id = DB::table('customers')->insertGetId([
                'contact1' => $validatedData['phone'],
                'cust_city' => $validatedData['city'],
                'cust_password' => $validatedData['password'],
            ]);

            session(['user' => $id]);

            return redirect('index.html');
        } catch (\Exception $e) {

            return back()->with('message', 'already registered user !');
        }
    }

    public function updatecustomer()
    {

        if (session()->has('user')) {

            $user = DB::table('customers')->where('id', session()->get('user'))->first();
            return view('userprofile', ['usersdata' => $user]);
        } else {

            return redirect('register.html');
        }
    }

    public function storeupdatecustomer(Request $request)
    {
        $validatedData = $request->validate([
            'fname' => 'alpha|max:20',
            'lname' => 'alpha|max:20',
            'phone' => 'digits:10',
            'city' => 'alpha|max:20',
            'email' => 'email',
            'password' => 'alpha_num|min:8|max:15'
        ]);
        try {
            $id = DB::table('customers')->updateOrInsert(
                [
                    'id' => $request->input('userid')
                ],
                [
                    'first_name' => $validatedData['fname'],
                    'last_name' => $validatedData['lname'],
                    'contact1' => $validatedData['phone'],
                    'cust_city' => $validatedData['city'],
                    'cust_password' => $validatedData['password'],
                    'cust_mail' => $validatedData['email'],
                    'cust_gender' => $request->input('gender')
                ]
            );
            return back()->with('msg', 'Updated Successfully !');
        } catch (\Exception $e) {

            return back()->with('msg', 'Failed to Update !');;
        }
    }


    public function logincustomer(Request $request)
    {
        //very very imp
        $validatedData = $request->validate([
            'phone' => 'digits:10|required',
            'password' => 'alpha_num|min:8|max:15|required'
        ]);

        $users = DB::table('customers')->where([
            ['contact1', '=', $validatedData['phone']],
            ['cust_password', '=',  $validatedData['password']],
        ])->value('id');

        if (empty($users)) {
            return back()->with('faillogin', 'Incorrect Mobile Number and Password');
        } else {


            session(['user' => $users]);

            return redirect('index.html');
        }
    }


    public function logoutcustomer()
    {
        session()->flush();
        return redirect('login.html');
    }

    public function registergarageshow()
    {

        if (session()->has('user')) {

            $user = DB::table('customers')->where('id', session()->get('user'))->first();
            $services = DB::table('services')->get();
            return view('registergarageform', ['usersdata' => $user, 'services' => $services]);
        } else {

            return redirect('register.html');
        }
    }

    public function registerservicecentershow()
    {


        if (session()->has('user')) {

            $user = DB::table('customers')->where('id', session()->get('user'))->first();
            $services = DB::table('services')->get();
            return view('registerservicecenterform', ['usersdata' => $user, 'services' => $services]);
        } else {

            return redirect('register.html');
        }
    }


    public function storeregistergarage(Request $request)
    {
        $validatedData = $request->validate([
            'fname' => 'alpha|max:20',
            'lname' => 'alpha|max:20',
            'grgname' => 'max:30',
            'phone1' => 'digits:10',
            'phone2' => 'digits:10',
            'phone3' => 'digits:10',
            'grgstate' => 'alpha',
            'city' => 'alpha|max:20',
            'grgaddress1' => 'max:255',

        ]);


        try {

            if ($request->input('shoptype') == 'garage') {
                $id = DB::table('garageinfo')->insertGetId([

                    'garage_name' => $validatedData['grgname'],
                    'garage_state' => $validatedData['grgstate'],
                    'garage_city' => $validatedData['city'],
                    'garage_address' => $validatedData['grgaddress1'],
                    'owner_id' => $request->input('userid'),
                    'opening_time'=>$request->input('opentime'),
                    'closing_time'=>$request->input('closetime')
                ]);
            } else if ($request->input('shoptype') == 'servicecenter') {
                $id = DB::table('garageinfo')->insertGetId([

                    'garage_name' => $validatedData['grgname'],
                    'garage_state' => $validatedData['grgstate'],
                    'garage_city' => $validatedData['city'],
                    'garage_address' => $validatedData['grgaddress1'],
                    'owner_id' => $request->input('userid'),
                    'is_service_center' => 1,
                    'service_center_type' => $request->input('grgtype'),
                    'service_center_brand' => $request->input('brand'),
                    'opening_time'=>$request->input('opentime'),
                    'closing_time'=>$request->input('closetime')
                ]);
            }

            if ($request->has('grgvehtype')) {

                foreach ($request->input('grgvehtype') as $gtype) {
                    $id2 = DB::table('garagetypes')->insertGetId([
                        'garage_type' => $gtype,
                        'garage_id' => $id
                    ]);
                }
            }

            if ($request->has('grgservices')) {

                foreach ($request->input('grgservices') as $gservices) {
                    $id3 = DB::table('garageservices')->insertGetId([
                        'service_id' => $gservices,
                        'price' => 0,
                        'garage_id' => $id
                    ]);
                }
            }

            $id1 = DB::table('customers')->updateOrInsert(
                [
                    'id' => $request->input('userid')
                ],
                [
                    'first_name' => $validatedData['fname'],
                    'last_name' => $validatedData['lname'],
                    'contact1' => $validatedData['phone1'],
                    'contact2' => $validatedData['phone2'],
                    'cust_whatsapp' => $validatedData['phone3'],
                    'cust_city' => $validatedData['city'],

                ]
            );


            $i = 1;
            if ($request->hasFile('images')) {

                foreach ($request->file('images') as $gimgs) {
                    $imgpath = 'public/img/garages';
                    $imagename = $id . $i . $validatedData['grgname'] . '.' . $gimgs->extension();

                    $gimgs->storeAs($imgpath, $imagename);

                    $id6 = DB::table('garagephotos')->insertGetId([
                        'garage_photo' => $imagename,
                        'garage_id' => $id
                    ]);
                    $i++;
                }
            }



            return back()->with('registergrg', 'Registered Successfully !');
        } catch (\Exception $e) {

            return back()->with('registergrg', 'Failed to Register !');
        }
    }

    public function showregisteredgarages()
    {

        $garageinfo = DB::table('garageinfo')->where([
            ['garage_city', session()->get('cityname')],
            ['is_service_center',NULL]
        ])->get();

        return view('garages', ['garageinfo' => $garageinfo]);
    }

    public function showregisteredservicecenters()
    {

        $garageinfo = DB::table('garageinfo')->where([
            ['garage_city', session()->get('cityname')],
            ['is_service_center',1]
        ])->get();

        return view('servicecenters', ['garageinfo' => $garageinfo]);
    }


    public function getgaragebyid($id){

        $garageinfo=DB::table('garageinfo')->where('id',$id)->first();
        $owner=DB::table('customers')->where('id',$garageinfo->owner_id)->first();
        return view('garageinfo', ['garageinfo' => $garageinfo,'owner'=>$owner]);
    }

    public function showservices($id){

        $services=DB::table('garageservices')->where('garage_id',$id)->get('service_id');

        return view('pricecard',['services'=>$services]);
    }

    public function storecustomerreviews(Request $request){

        $custreview=DB::table('customerreviews')->insertGetId([
            'customer_id' => session()->get('user'),
            'garage_id' => $request->input('grgid'),
            'comment'=>$request->input('customercomment'),
            'ratings'=>$request->input('radio'),
            'created_at'=> date('Y-m-d H:i:s')
        ]);

        return back();
    }
}
