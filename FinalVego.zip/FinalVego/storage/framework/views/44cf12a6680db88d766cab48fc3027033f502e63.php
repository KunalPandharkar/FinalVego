<?php $__env->startSection('title', 'VeGO-Aapka Apna Garage!'); ?>
<?php $__env->startSection('searchbar'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('userlocation'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- login form -->
    <section class="defaultcard">
        <div class="heading">
            <h5>My Profile</h5>
            <hr class="headingunderline">
        </div>
        <div class="userprofile-in">
            <div class="usericon ui1">
                <img src="assets/images/user.svg" alt="">
            </div>
            <div class="username un1">

                <p>Hello, <?php echo e($usersdata->first_name); ?> </p>
                <p>+91 <?php echo e($usersdata->contact1); ?></p>


            </div>

        </div>
        <?php if($message = Session::get('updatesuccess')): ?>
            <div class="alert alert-success loginsucess alert-dismissible fade show" role="alert">
                <?php echo e($message); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if($message = Session::get('updatenodata')): ?>
            <div class="alert alert-warning loginsucess alert-dismissible fade show" role="alert">
                <?php echo e($message); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <?php if($message = Session::get('updatefailed')): ?>
            <div class="alert alert-danger loginsucess alert-dismissible fade show" role="alert">
                <?php echo e($message); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>

            </div>
        <?php endif; ?>
        <form action="updatecustomer" method="post">
            <?php echo csrf_field(); ?>
            <div class="usereditform">
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">First Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="first_name"
                        value="<?php echo e($usersdata->first_name); ?>">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Last Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="last_name"
                        value="<?php echo e($usersdata->last_name); ?>">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Your City</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="cust_city"
                        value="<?php echo e($usersdata->cust_city); ?>">
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Mobile Number</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="phone"
                        value="<?php echo e($usersdata->contact1); ?>">
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Mobile Number 2</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="number"
                        value="<?php echo e($usersdata->contact2); ?>">
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <div class="form-group fg-log">
                    <label for="exampleInputEmail1">Password</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="password"
                        value="<?php echo e($usersdata->cust_password); ?>">
                </div>
                <div class="form-group fg-log us-gender">
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="gender" id="inlineRadio1" value="male"
                        <?php if($usersdata->cust_gender === 'male'): ?>
                        checked
                        <?php endif; ?>
                        >

                        <label class="form-check-label" for="inlineRadio1">Male</label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" id="inlineRadio2" value="female" name="gender"
                        <?php if($usersdata->cust_gender === 'female'): ?>
                        checked
                        <?php endif; ?>
                        >
                        <label class="form-check-label" for="inlineRadio2">Female</label>
                    </div>
                </div>
                <div class="form-group fg-log fg-space">
                    <label for="exampleInputEmail1">Email ID</label>
                    <input type="text" class="form-control" id="exampleFormControlInput1" name="mail"
                        value="<?php echo e($usersdata->cust_mail); ?>">
                    <small class=" underinputerror">
                        <?php $__errorArgs = ['mail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <?php echo e($message); ?>

                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </small>
                </div>
                <input type="hidden" name="user_id" value="<?php echo e($usersdata->id); ?>">
            </div>

            <div class="fg-us">
                <button type="" class="btn rst">Reset</button>
                <button type="submit" class="btn">Update</button>
            </div>
        </form>
    </section>
    <!-- loginform ends -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Projects\FinalVego\FinalVego\resources\views/userprofile.blade.php ENDPATH**/ ?>